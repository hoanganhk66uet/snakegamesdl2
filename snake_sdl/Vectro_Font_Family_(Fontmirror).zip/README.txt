To learn more about the font family and its license, visit https://www.fontmirror.com/vectro

License: Free for personal use.Contact variatype.id@gmail.com for commercial use.